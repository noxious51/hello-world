const Helloworld = artifacts.require("Helloworld");

contract("Helloworld", () => {
    it("should deploy the smart contract correcty", async () => {
    const Helloworld = await Helloworld.deployed();
    console.log(Helloworld);
    assert(Helloworld.adresse !== "" && Helloworld.adress !== undefined);
    })

    it("should return hello worl", async () => {
        const Helloworld = await Helloworl.deployed();
        console.log(result);
        assert(result== "Helloworld");
    })
})